echo "{\"user\":{\"password\":\"user\",\"date\":[],\"rating\":[],\"history\":[]},
\"adrien\":{\"password\":\"adrien\",\"date\":[],\"rating\":[],\"history\":[]}}" > file.json
