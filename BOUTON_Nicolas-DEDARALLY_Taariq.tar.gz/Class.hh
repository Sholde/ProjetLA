#ifndef _Class_hh
#define _Class_hh

class Box;
class BoxCircle;
class Module;
class Pompe;
class System;
class Vanne;
class VanneNormal;
class VanneTransi;
class Reservoir;
class Moteur;
class Interface;
class Utilisateur;

#endif
